export interface SearchModel {
  title: string;
  type: string;
}

