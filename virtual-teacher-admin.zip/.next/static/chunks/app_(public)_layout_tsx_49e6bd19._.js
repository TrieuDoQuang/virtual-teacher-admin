(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(public)_layout_tsx_49e6bd19._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(public)_layout_tsx_49e6bd19._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0097c112._.js",
    "static/chunks/node_modules_6524ba9c._.js",
    "static/chunks/components_0f51981b._.js"
  ],
  "source": "dynamic"
});
