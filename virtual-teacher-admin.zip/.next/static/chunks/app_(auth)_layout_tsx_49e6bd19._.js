(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(auth)_layout_tsx_49e6bd19._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(auth)_layout_tsx_49e6bd19._.js",
  "chunks": [
    "static/chunks/app_(auth)_layout_tsx_3e4d353c._.js"
  ],
  "source": "dynamic"
});
