export interface AuditableModel {
    createdAt: string;
    updatedAt: string;
}


