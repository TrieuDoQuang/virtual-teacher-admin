(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_lessons_page_tsx_5eb2399f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_lessons_page_tsx_5eb2399f._.js",
  "chunks": [
    "static/chunks/_dffadb51._.js",
    "static/chunks/node_modules_044f2c40._.js"
  ],
  "source": "dynamic"
});
