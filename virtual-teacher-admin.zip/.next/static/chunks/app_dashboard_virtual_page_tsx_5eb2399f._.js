(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_virtual_page_tsx_5eb2399f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_virtual_page_tsx_5eb2399f._.js",
  "chunks": [
    "static/chunks/_df84fb4d._.js",
    "static/chunks/node_modules_aa1cafab._.js"
  ],
  "source": "dynamic"
});
