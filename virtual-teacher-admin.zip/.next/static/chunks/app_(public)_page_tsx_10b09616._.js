(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(public)_page_tsx_10b09616._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(public)_page_tsx_10b09616._.js",
  "chunks": [
    "static/chunks/node_modules_@splinetool_runtime_build_219b22d7._.js",
    "static/chunks/node_modules_@splinetool_runtime_build_runtime_ef1768d2.js",
    "static/chunks/node_modules_cc3c27ea._.js"
  ],
  "source": "dynamic"
});
