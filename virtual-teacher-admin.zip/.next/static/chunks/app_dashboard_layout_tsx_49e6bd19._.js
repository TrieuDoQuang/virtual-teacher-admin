(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_layout_tsx_49e6bd19._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_layout_tsx_49e6bd19._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_a7c294a5._.js",
    "static/chunks/_15cdc8e3._.js",
    "static/chunks/node_modules_framer-motion_dist_es_872de39c._.js",
    "static/chunks/node_modules_673484d6._.js"
  ],
  "source": "dynamic"
});
