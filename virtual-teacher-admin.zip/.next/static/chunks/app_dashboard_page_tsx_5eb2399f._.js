(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_page_tsx_5eb2399f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_page_tsx_5eb2399f._.js",
  "chunks": [
    "static/chunks/node_modules_lodash_41ab3ad4._.js",
    "static/chunks/node_modules_recharts_es6_0259fdfd._.js",
    "static/chunks/node_modules_9ba7f53a._.js",
    "static/chunks/_1fc91ffc._.js"
  ],
  "source": "dynamic"
});
