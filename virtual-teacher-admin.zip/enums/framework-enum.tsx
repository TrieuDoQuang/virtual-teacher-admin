export enum VirtualTeacherAction { 
    CREATE = "CREATE",
    UPDATE = "UPDATE",
    DELETE = "DELETE",
}
