(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_account_page_tsx_5eb2399f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_account_page_tsx_5eb2399f._.js",
  "chunks": [
    "static/chunks/_03719dc9._.js",
    "static/chunks/node_modules_eaab7dd9._.js"
  ],
  "source": "dynamic"
});
