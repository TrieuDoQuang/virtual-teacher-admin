export interface SettingModel {
    id: string;
    value: string;
}
