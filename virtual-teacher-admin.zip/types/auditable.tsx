export type Auditable = {
  createdAt: string;
  updatedAt: string;
};
