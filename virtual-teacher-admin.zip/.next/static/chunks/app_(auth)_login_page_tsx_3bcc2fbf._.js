(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(auth)_login_page_tsx_3bcc2fbf._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(auth)_login_page_tsx_3bcc2fbf._.js",
  "chunks": [
    "static/chunks/node_modules_zod_lib_index_mjs_ee760afb._.js",
    "static/chunks/node_modules_framer-motion_dist_es_872de39c._.js",
    "static/chunks/node_modules_32d74636._.js",
    "static/chunks/_f839a41c._.js"
  ],
  "source": "dynamic"
});
