export type Navbar = {
    name: string;
    href: string;
}
